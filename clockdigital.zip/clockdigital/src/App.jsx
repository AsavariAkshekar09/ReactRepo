import Clock from "./Clock";

function App() {
  return (
    <div className="App">
      <Clock />
    </div>
  );
}

export default App;
